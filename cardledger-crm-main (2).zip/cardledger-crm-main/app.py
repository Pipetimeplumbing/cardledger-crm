import csv
import io
import os
import sqlite3
import tempfile
from contextlib import contextmanager
from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
from urllib.parse import urlsplit
from flask import Flask, jsonify, request, Response, send_file

ROOT = Path(__file__).parent
DB = Path(os.environ.get('DATABASE_PATH', str(ROOT / 'data' / 'collection.sqlite')))
DB.parent.mkdir(parents=True, exist_ok=True)
app = Flask(__name__, static_folder='public', static_url_path='')
app.config['MAX_CONTENT_LENGTH'] = 32000

@contextmanager
def connection():
    db = sqlite3.connect(DB, timeout=15)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

with connection() as db:
    db.executescript('''
        CREATE TABLE IF NOT EXISTS cards (
          id INTEGER PRIMARY KEY, player TEXT NOT NULL, sport TEXT NOT NULL,
          year TEXT NOT NULL, brand TEXT NOT NULL, card_number TEXT NOT NULL,
          grade TEXT NOT NULL, notes TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity>=0),
          total_cost INTEGER NOT NULL CHECK(total_cost>=0), market_price INTEGER NOT NULL CHECK(market_price>=0),
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS clients (
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL,
          phone TEXT NOT NULL, notes TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS sales (
          id INTEGER PRIMARY KEY, card_id INTEGER NOT NULL REFERENCES cards(id),
          client_id INTEGER REFERENCES clients(id), quantity INTEGER NOT NULL CHECK(quantity>0),
          revenue INTEGER NOT NULL, cost_basis INTEGER NOT NULL, fees INTEGER NOT NULL,
          shipping INTEGER NOT NULL, sold_on TEXT NOT NULL, channel TEXT NOT NULL,
          notes TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS purchases (
          id INTEGER PRIMARY KEY, card_id INTEGER NOT NULL REFERENCES cards(id),
          quantity INTEGER NOT NULL, total_cost INTEGER NOT NULL,
          purchased_on TEXT NOT NULL DEFAULT CURRENT_DATE);
    ''')

def text(data, key, required=False, limit=200):
    value = data.get(key, '')
    if not isinstance(value, str) or len(value) > limit or (required and not value.strip()):
        raise ValueError(f'Enter a valid {key.replace("_", " ")}.')
    return value.strip()

def integer(data, key, minimum=1):
    value = data.get(key)
    if isinstance(value, bool) or not isinstance(value, (str, int)):
        raise ValueError(f'Enter a whole number for {key}.')
    try:
        result = int(str(value))
    except ValueError:
        raise ValueError(f'Enter a whole number for {key}.')
    if not minimum <= result <= 1000000:
        raise ValueError(f'{key.capitalize()} must be between {minimum} and 1,000,000.')
    return result

def money(data, key):
    value = data.get(key, '0')
    if isinstance(value, bool):
        raise ValueError(f'Enter a valid amount for {key}.')
    try:
        amount = Decimal(str(value))
        if not amount.is_finite() or amount < 0 or amount > 10000000:
            raise ValueError()
        return int((amount * 100).quantize(Decimal('1'), rounding=ROUND_HALF_UP))
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError(f'Enter a non-negative amount for {key.replace("_", " ")}.')

def json_data():
    value = request.get_json(silent=True)
    if not isinstance(value, dict):
        raise ValueError('Invalid request data.')
    return value

@app.before_request
def protect_requests():
    if request.method in ('POST', 'PATCH'):
        origin = request.headers.get('Origin')
        if origin and urlsplit(origin).netloc != request.host:
            return jsonify(error='Request origin not allowed.'), 403
        if not request.is_json:
            return jsonify(error='Send JSON data.'), 415

@app.after_request
def headers(response):
    if request.path.startswith('/api/'):
        response.headers['Cache-Control'] = 'no-store'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    return response

@app.errorhandler(ValueError)
def bad_input(error):
    return jsonify(error=str(error)), 400

@app.errorhandler(413)
def too_large(error):
    return jsonify(error='Request is too large.'), 413

@app.get('/')
def home():
    return app.send_static_file('index.html')

@app.get('/api/state')
def state():
    with connection() as db:
        cards = [dict(row) for row in db.execute('SELECT * FROM cards ORDER BY created_at DESC,id DESC')]
        clients = [dict(row) for row in db.execute('SELECT c.*,COUNT(s.id) AS sale_count,COALESCE(SUM(s.revenue),0) AS spend FROM clients c LEFT JOIN sales s ON s.client_id=c.id GROUP BY c.id ORDER BY c.name')]
        sales = [dict(row) for row in db.execute('SELECT s.*,c.player,c.brand,c.year,c.card_number,c.grade,cl.name AS client_name FROM sales s JOIN cards c ON c.id=s.card_id LEFT JOIN clients cl ON cl.id=s.client_id ORDER BY s.sold_on DESC,s.id DESC')]
    totals = dict(stock=sum(c['quantity'] for c in cards), unique_cards=sum(c['quantity']>0 for c in cards), cost_value=sum(c['total_cost'] for c in cards), market_value=sum(c['quantity']*c['market_price'] for c in cards), revenue=sum(s['revenue'] for s in sales), profit=sum(s['revenue']-s['cost_basis']-s['fees']-s['shipping'] for s in sales), sold=sum(s['quantity'] for s in sales), clients=len(clients))
    return jsonify(cards=cards, clients=clients, sales=sales, totals=totals)

@app.post('/api/cards')
def add_card():
    data = json_data()
    fields = [text(data,k,k in ('player','sport')) for k in ('player','sport','year','brand','card_number','grade')]
    notes = text(data,'notes',limit=3000)
    quantity, cost, market = integer(data,'quantity'), money(data,'unit_cost'), money(data,'market_price')
    with connection() as db:
        cur = db.execute('INSERT INTO cards(player,sport,year,brand,card_number,grade,notes,quantity,total_cost,market_price) VALUES(?,?,?,?,?,?,?,?,?,?)', (*fields,notes,quantity,quantity*cost,market))
        db.execute('INSERT INTO purchases(card_id,quantity,total_cost) VALUES(?,?,?)',(cur.lastrowid,quantity,quantity*cost))
    return jsonify(id=cur.lastrowid),201

@app.patch('/api/cards/<int:identifier>')
def edit_card(identifier):
    data = json_data()
    fields = [text(data,k,k in ('player','sport')) for k in ('player','sport','year','brand','card_number','grade')]
    with connection() as db:
        cur=db.execute('UPDATE cards SET player=?,sport=?,year=?,brand=?,card_number=?,grade=?,notes=?,market_price=? WHERE id=?',(*fields,text(data,'notes',limit=3000),money(data,'market_price'),identifier))
        if not cur.rowcount: return jsonify(error='Card not found.'),404
    return jsonify(ok=True)

@app.post('/api/cards/<int:identifier>/restock')
def restock(identifier):
    data=json_data();quantity=integer(data,'quantity');cost=money(data,'unit_cost')
    with connection() as db:
        db.execute('BEGIN IMMEDIATE')
        card=db.execute('SELECT quantity FROM cards WHERE id=?',(identifier,)).fetchone()
        if not card: return jsonify(error='Card not found.'),404
        if card['quantity']+quantity>1000000: raise ValueError('Stock cannot exceed 1,000,000 pieces.')
        db.execute('UPDATE cards SET quantity=quantity+?,total_cost=total_cost+? WHERE id=?',(quantity,quantity*cost,identifier))
        db.execute('INSERT INTO purchases(card_id,quantity,total_cost) VALUES(?,?,?)',(identifier,quantity,quantity*cost))
    return jsonify(ok=True)

@app.post('/api/clients')
@app.patch('/api/clients/<int:identifier>')
def save_client(identifier=None):
    data=json_data();fields=[text(data,'name',True),text(data,'email'),text(data,'phone'),text(data,'notes',limit=3000)]
    with connection() as db:
        if identifier is None:
            cur=db.execute('INSERT INTO clients(name,email,phone,notes) VALUES(?,?,?,?)',fields)
            identifier=cur.lastrowid
        else:
            cur=db.execute('UPDATE clients SET name=?,email=?,phone=?,notes=? WHERE id=?',(*fields,identifier))
            if not cur.rowcount:return jsonify(error='Client not found.'),404
    return jsonify(id=identifier),201 if request.method=='POST' else 200

@app.post('/api/sales')
def record_sale():
    data=json_data();card_id=integer(data,'card_id');quantity=integer(data,'quantity')
    unit_price,fees,shipping=money(data,'unit_price'),money(data,'fees'),money(data,'shipping')
    client_id=integer(data,'client_id') if data.get('client_id') not in ('',None) else None
    sold_on=text(data,'sold_on',True)
    try:
        sold=date.fromisoformat(sold_on)
        if sold>date.today():raise ValueError()
    except ValueError:raise ValueError('Choose a valid sale date that is not in the future.')
    channel,notes=text(data,'channel'),text(data,'notes',limit=3000)
    with connection() as db:
        db.execute('BEGIN IMMEDIATE')
        card=db.execute('SELECT * FROM cards WHERE id=?',(card_id,)).fetchone()
        if not card:return jsonify(error='Card not found.'),404
        if quantity>card['quantity']:raise ValueError(f'Only {card["quantity"]} pieces are in stock.')
        if client_id and not db.execute('SELECT id FROM clients WHERE id=?',(client_id,)).fetchone():raise ValueError('Client not found.')
        # Allocate the exact remaining cost basis; final sale consumes any cent remainder.
        basis=int((Decimal(card['total_cost'])*quantity/card['quantity']).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
        db.execute('UPDATE cards SET quantity=quantity-?,total_cost=total_cost-? WHERE id=?',(quantity,basis,card_id))
        cur=db.execute('INSERT INTO sales(card_id,client_id,quantity,revenue,cost_basis,fees,shipping,sold_on,channel,notes) VALUES(?,?,?,?,?,?,?,?,?,?)',(card_id,client_id,quantity,unit_price*quantity,basis,fees,shipping,sold_on,channel,notes))
    return jsonify(id=cur.lastrowid),201

def safe_cell(value):
    return "'"+value if isinstance(value,str) and value.lstrip().startswith(('=','+','-','@')) else value

@app.get('/api/export/<kind>')
def export(kind):
    with connection() as db:
        if kind=='inventory':
            rows=db.execute('SELECT player,sport,year,brand,card_number,grade,quantity,ROUND(total_cost/100.0,2) AS purchase_cost_usd,ROUND(market_price/100.0,2) AS estimated_unit_value_usd,notes FROM cards').fetchall()
            names=['player','sport','year','brand','card_number','grade','quantity','purchase_cost_usd','estimated_unit_value_usd','notes']
        elif kind=='clients':
            rows=db.execute('SELECT name,email,phone,notes FROM clients').fetchall();names=['name','email','phone','notes']
        elif kind=='sales':
            rows=db.execute('SELECT s.sold_on,c.player,cl.name,s.quantity,s.revenue/100.0,s.cost_basis/100.0,s.fees/100.0,s.shipping/100.0,(s.revenue-s.cost_basis-s.fees-s.shipping)/100.0,s.channel,s.notes FROM sales s JOIN cards c ON c.id=s.card_id LEFT JOIN clients cl ON cl.id=s.client_id ORDER BY s.sold_on DESC').fetchall()
            names=['date','player','client','quantity','revenue_usd','cost_basis_usd','fees_usd','shipping_usd','profit_usd','channel','notes']
        else:return jsonify(error='Export not found.'),404
    output=io.StringIO();writer=csv.writer(output);writer.writerow(names)
    writer.writerows([[safe_cell(value) for value in row] for row in rows])
    return Response(output.getvalue(),mimetype='text/csv',headers={'Content-Disposition':f'attachment; filename="cardledger-{kind}.csv"'})

@app.get('/api/backup')
def backup():
    with tempfile.TemporaryDirectory() as directory:
        path=Path(directory)/'backup.sqlite'
        with connection() as source, sqlite3.connect(path) as target:source.backup(target)
        data=io.BytesIO(path.read_bytes())
    return send_file(data,mimetype='application/octet-stream',as_attachment=True,download_name=f'cardledger-{date.today()}.sqlite')

if __name__=='__main__':
    app.run(host='127.0.0.1',port=int(os.environ.get('PORT','3001')),debug=False)
